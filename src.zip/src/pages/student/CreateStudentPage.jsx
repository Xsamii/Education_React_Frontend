import React, { useState, useEffect } from "react";
import {
  TextField,
  Button,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Container,
  Typography,
} from "@mui/material";
import axios from "axios";

const CreateStudentPage = () => {
  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [parentNumber, setParentNumber] = useState("");
  const [studyYear, setStudyYear] = useState("");
  const [studyYears, setStudyYears] = useState([
    "Freshman",
    "Sophomore",
    "Junior",
    "Senior",
  ]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await axios.post("/api/students", {
        name,
        phoneNumber,
        email,
        parentNumber,
        studyYear,
      });
      // handle success, maybe clear the form or notify user
    } catch (error) {
      // handle error
    }
  };

  return (
    <Container maxWidth="sm">
      <Typography variant="h4" component="h1" gutterBottom>
        Create Student
      </Typography>
      <form onSubmit={handleSubmit}>
        <TextField
          label="Name"
          fullWidth
          margin="normal"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <TextField
          label="Phone Number"
          fullWidth
          margin="normal"
          value={phoneNumber}
          onChange={(e) => setPhoneNumber(e.target.value)}
          required
        />
        <TextField
          label="Email"
          fullWidth
          margin="normal"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <TextField
          label="Parent Number"
          fullWidth
          margin="normal"
          value={parentNumber}
          onChange={(e) => setParentNumber(e.target.value)}
          required
        />
        <FormControl fullWidth margin="normal">
          <InputLabel>Study Year</InputLabel>
          <Select
            value={studyYear}
            onChange={(e) => setStudyYear(e.target.value)}
            required
          >
            {studyYears.map((year, index) => (
              <MenuItem key={index} value={year}>
                {year}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <Button type="submit" variant="contained" color="primary" fullWidth>
          Create
        </Button>
      </form>
    </Container>
  );
};

export default CreateStudentPage;

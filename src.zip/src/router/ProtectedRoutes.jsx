import React from "react";
import { Route, Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../contexts/authContext";
import Layout from "./Layout";
import { mainRoutes } from "./mainRoutes";

const ProtectedRoute = () => {
  // const { loggedIn } = useAuth();
  const loggedIn = true;

  return loggedIn ? <Outlet /> : <Navigate to="/login" replace />;
};

export default ProtectedRoute;

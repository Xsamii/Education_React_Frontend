import LoginPage from "../pages/LoginPage";
import FunctionPage from "../pages/functionPage";
import SessionsPage from "../pages/session";
import CreateSession from "../pages/session/AddSession";
import StudentsPage from "../pages/student";
import CreateStudentPage from "../pages/student/CreateStudentPage";
import TeachersPage from "../pages/teacher";
import HomePage from "../pages/Home";
export const mainRoutes = [
  // {
  //   path: "/login",
  //   element: <LoginPage />,
  // },
  {
    path: "/home",
    element: <HomePage />,
  },
  {
    path: "/students",
    element: <StudentsPage />,
  },
  {
    path: "/teachers",
    element: <TeachersPage />,
  },
  {
    path: "/sessions",
    element: <SessionsPage />,
  },
  {
    path: "/dashboard",
    element: <h1>dashboard page</h1>,
  },
  {
    path: "/functions",
    element: <FunctionPage />,
  },
  {
    path: "/add-session",
    element: <CreateSession />,
  },
  {
    path: "/add-student",
    element: <CreateStudentPage />,
  },
  {
    path: "/students/create",
    element: <CreateStudentPage />,
  },
  {
    path: "/student/all",
    element: <></>,
  },
  {
    path: "/teachers/create",
    element: <>Create Teacher</>,
  },
  {
    path: "/teacher/all",
    element: <></>,
  },
  {
    path: "/sessions/create",
    element: <CreateSession />,
  },
  {
    path: "/sessions/all",
    element: <>all sessions</>,
  },
];

export const studentRouts = [
  {
    path: "/student/create",
    element: <CreateStudentPage />,
  },
  {
    path: "/student/all",
    element: <></>,
  },
];
export const teacherRouts = [
  {
    path: "/teacher/create",
    element: <>Create Teacher</>,
  },
  {
    path: "/teacher/all",
    element: <></>,
  },
];

export const sessionsRoutes = [
  {
    path: "/sessions/create",
    element: <CreateSession />,
  },
  {
    path: "/sessions/all",
    element: <>all sessions</>,
  },
];
